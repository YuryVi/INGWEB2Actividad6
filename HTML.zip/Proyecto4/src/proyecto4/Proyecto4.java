//Crear un programa que añada números a una lista hasta que introducimos un 
//número negativo. A continuación, debe crear una nueva lista igual que la anterior,
//pero eliminando los números duplicados. Muestra esta segunda lista para 
//comprobar que hemos eliminados los duplicados
package proyecto4;

import java.util.Scanner;

public class Proyecto4 {

    public static void main(String[] args) {
        Scanner n=new Scanner(System.in);
        int num,suma,elementos;

        System.out.println("Introduzca un numero: ");
        num=n.nextInt();

        suma=0;
        elementos=0;

        while(num>=0){

        suma+=num;
        elementos++;

        System.out.println("Introduzca otro numero: ");
        num=n.nextInt();

        if (elementos==0){

            System.out.println("Imposible continuar");
}

}
    }
    
}
