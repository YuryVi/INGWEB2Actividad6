
package proyecto3;

import java.util.Objects;

public class Matricula {

    static boolean add(Matrciula myMatricula) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    private String NombreEst;
    private String ApellidoEst;
    private String DocumentoEst;
    private String NombreCourse;
    private String DurCourse;
    private String CapacityCourse;


    public Matricula(String NombreEst, String ApellidoEst, String DocumentoEst, String NombreCourse, String DurCourse, String CapacityCourse) {
        this.NombreEst = NombreEst;
        this.ApellidoEst = ApellidoEst;
        this.DocumentoEst = DocumentoEst;
        this.NombreCourse = NombreCourse;
        this.DurCourse = DurCourse;
        this.CapacityCourse = CapacityCourse;
    }

    public String getNombreEst() {
        return NombreEst;
    }

    public void setNombreEst(String NombreEst) {
        this.NombreEst = NombreEst;
    }

    public String getApellidoEst() {
        return ApellidoEst;
    }

    public void setApellidoEst(String ApellidoEst) {
        this.ApellidoEst = ApellidoEst;
    }

    public String getDocumentoEst() {
        return DocumentoEst;
    }

    public void setDocumentoEst(String DocumentoEst) {
        this.DocumentoEst = DocumentoEst;
    }

    public String getNombreCourse() {
        return NombreCourse;
    }

    public void setNombreCourse(String NombreCourse) {
        this.NombreCourse = NombreCourse;
    }

    public String getDurCourse() {
        return DurCourse;
    }

    public void setDurCourse(String DurCourse) {
        this.DurCourse = DurCourse;
    }

    public String getCapacityCourse() {
        return CapacityCourse;
    }

    public void setCapacityCourse(String CapacityCourse) {
        this.CapacityCourse = CapacityCourse;
    }

    

@Override
public boolean equals(Object obj) {
if (this == obj){
return true;
}
if (obj == null){
return false;
}
if (getClass()!=obj.getClass()){
return false;
}
final Matricula other = (Matricula) obj;
return Objects.equals(this.nameEst, other.nameEst);
}


    @Override
    public String toString() {
        StringBuiler sb = new StringBuiler();
        sb.append("Matricula{");
        sb.append(", nombreEst=").append(nombreEst);
        sb.append(", apellidoEst=").append(apellidoEst);
        sb.append(", documentoEst=").append(documentoEst);
        sb.append(", nombreCourse=").append(nombreCourse);
        sb.append(", durCourse=").append(durCourse);
        sb.append(", CapacityCourse=").append(capacityCourse);
        sb.append('}');
        return sb.toString();
    }

    void setCapacity(int cap) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

