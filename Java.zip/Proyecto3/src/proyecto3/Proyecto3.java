
package proyecto3;
//Crear un programa que permita la matrícula de N estudiantes, se debe guardar 
//los datos del estudiante: nombres, apellidos, documento también se debe guardar 
//los datos del curso que va inscribir, del curso: id de curso, nombre del curso, 
//duración, capacidad. Un estudiante solo puede matricular un curso y un curso puede 
//matricular la cantidad de estudiante que dice su capacidad. Mostrar un menú con 
//las sgtes opciones: *Agregar estudiante * Matricular estudiante, * Eliminar 
//estudiante, *Actualizar Estudiante, *Listar estudiantes, *Listar estudiantes con 
//matrícula, *Agregar curso, *Eliminar Curso *Listar Cursos

import javax.swing.JOptionPane;

public class Proyecto3 {

 
        public static void main(String[] args) {
        static Inventory inventory;
        private Matricula Matricula;

    public static void main(String[] args) {
     
begin();
    }
    
public static void begin(){
inventory = new Inventory();
short option =0;
do{
option = Short.parseShort(JOptionPane.showInputDialog("Menù de opciones\n"
 + "1.Agregar Estudiante\n2.Matricular Estudiante\n3.Eliminar Estudiante\n4.Actualizar Estudiante\n5.Listar Estudiantes con matricula\6.Agregar Curso\n6.Eliminar Curso.\n7.Listar Cursos\n8.Salir"));
switch (option){
case 1:
newEstudiante();
break;
case 2:
addEstudiante();
break;
case 3:
DELEstudiante();
case 4:
updateEstudiante();
break;
case 5:
listEstudianteMat();
default:
break;
case 6:
addCourse();
default:
break;
case 7:
DELCourse();
default:
break;
case 8:
listCourse();
default:
break;
}
}while(option !=9);
}
private static void newMatricula(){
String name = JOptionPane.showInputDialog("Nombre Estudiante");
String description = JOptionPane.showInputDialog("ApellidoEstudiante");
String name = JOptionPane.showInputDialog("Documento Estudiante");
String description = JOptionPane.showInputDialog("Nombre del curso");
String description = JOptionPane.showInputDialog("Duraciòn del curso");
    int cap = Integer.parseInt(JOptionPane.showInputDialog("Capacidad del Curso"));
inventory.newCourse(name, lastname, doc, name course, durac, cap);
}
}

private static void updateMatricula(){
    String name = JOptionPane.showInputDialog("Nombre del estudiante a actualizar");
    String description = JOptionPane.showInputDialog("Nueva Description de Matrcicula");
    int cap = Integer.parseInt(JOptionPane.showInputDialog("Nueva Capacidad del Curso"));
    inventory.updateCourse(nombre, descripcion, capacidad);
}


private statica void listMatricula(){
inventory.printMatricula();
}

    }
    
}
