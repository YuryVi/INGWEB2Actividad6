
package proyecto3;

import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;

public class Inventory {
private List<Matricula> matricula;

public Inventory(){
this.matricula = new LinkedList<>();
}

public void newMatricula(String nombre,String apellido, String documento, String nombre curso, String duracion curso, int capac){
Matrciula myMatricula = new Matricula(nombre, apellido, documento, nombre curso, duracion, capac);
String msn = Matricula.add(myMatricula) ? "Se ha matriculado en el curso" : "no se matriculo en el curso";
JOptionPane.showMessageDialog(null, msn);

}

public void updateMatricula(String nombre,String apellido, String documento, String nombre curso, String duracion curso, int cap){
int matriculaIndex = matricula.indexOf(new Matricula(nombre));
Matricula findMatricula = matricula.get(matriculaIndex);
findMatricula.setCapacity(capac);
findMatricula.setDescpMatricula(descripcion);
JOptionPane.showMessageDialog(null, "se ha actualizado la matricula");
}

public void printMatricula(){
matricula.forEach(System.out::println);
}
}