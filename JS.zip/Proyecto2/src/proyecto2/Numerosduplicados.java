//Eliminar numeros duplicados
package proyecto2;

public class Numerosduplicados {

public static void main(String[] args) {
  int [] A = {1,2,3,4,5,2,8,9,5,1};
  int [] B = new int [A.length];

  int j,top=0;
  boolean repetido;

  for (int i=0; i<A.length; i++){
    repetido = false;
    j=0;
while(!repetido && (j<top)){
if(A[i] == B[j]){
repetido = true;
} 
j++;
}
if (!repetido){
B[top] = A[i];
top++;
}
}

System.out.print("Arreglo original: ");
for (int i=0; i<A.length; i++){
System.out.print(A[i]+" ");
}

System.out.print("Arreglo sin repetidos: ");
for (int i=0; i<top; i++){
System.out.print(B[i]+" ");
}
}
}
