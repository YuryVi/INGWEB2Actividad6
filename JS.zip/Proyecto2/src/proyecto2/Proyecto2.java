
package proyecto2;

//Ingresar a una lista enlazada simple n elementos y calcular cual es el mayor de la 

import java.util.Scanner;

//lista. Imprimir el número mayor y luego la lista
public class Proyecto2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);

        System.out.println("Numero mayor");
        System.out.println("Digite la cantidad de numeros a evaluar");

        int cantidadNumeros = scanner.nextInt();

        int numeroMayor=0;

        for (int i=0; i<cantidadNumeros; i++){
        System.out.println("Digite el numero en la posicion"+(1+i));
        int tmp = scanner.nextInt();
        if (i==0){
        numeroMayor=tmp;
        }else if (tmp>numeroMayor){
        numeroMayor=tmp;
}
}
        System.out.println("El numero mayor es"+numeroMayor);
}
    
}
