//A partir de un arreglo que posee N cantidad de promedios de estudiantes 
//colocarlos en una lista y sacar el promedio global de todos los estudiantes. Se debe 
//verificar que los elementos que están
//en la lista son correcto (rango de 0 a 5). Imprimir todos los promedios y el promedio 
//global
package proyecto1;

import java.util.Scanner;

/**
 *
 * @author yury_
 */
public class Proyecto1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float acum = 1; //acumulado
        float notas =0;
        Scanner r = new Scanner (System.in);
        System.out.println("Ingrese la cantidad de notas a promediar");
        float cn = r.nextFloat(); //Cantidad de notas

        while (acum <= cn){
        System.out.println("Ingrese la nota: "+acum);
        float n = r.nextFloat();
        notas += n;
        acum++;
}
        float promedio = notas / cn;

System.out.println("El promedio es:"+promedio);
    }
    
}
